# Greedy-coloring
Greedy coloring algorithm in C.
