# greedy_algo_for_TSP
Greedy algorithm for TSP
Enter Path  - CSV file with city name and XY Coordinates.You can use the tour files or provide your own.
Enter Start city.
